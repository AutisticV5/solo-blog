title: Java性能调优工具箱之Java监控工具
date: '2019-11-12 09:02:53'
updated: '2019-11-12 09:02:53'
tags: [Java性能调优]
permalink: /articles/2019/11/12/1573520573146.html
---
![](https://img.hacpai.com/bing/20180306.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

要想深入了解JVM自身，需要使用Java的监控工具。JDK自带以下所列工具

* jcmd它用来打印Java进程所涉及的基本类、线程和VM信息。它适用于脚本
    
    % jcmd process_id command optional_arguments
    
    jcmd help可以列出所有的命令。
    
* jconsole
    
    提供JVM活动的图形化视图，包括线程的使用，类的使用和GC活动
    
* jhat
    
    读取内存堆转储，并有助于分析。这是事后使用的工具
    
* jmap
    
    提供堆转储和其他JVM内存使用的信息。可以适用于脚本，但堆转储必须在事后分析工具中使用
    
* jinfo
    
    查看JVM的系统属性，可以动态设置一些系统属性。可适用于脚本
    
* jstack
    
    转储Java进程的栈信息。可适用于脚本
    
* jstat
    
    提供GC和类装载活动的信息。可适用于脚本
    
* jvisualvm
    
    监视JVM的GUI工具，可用来剖析运行的应用，分析JVM堆转储(时候活动，虽然jvisualvm也可以实时抓取程序的堆转储)
    

#### 基本的VM信息

* 查看JVM运行的时长
    
    % jcmd process_id VM.system_properties  
    或  
    % jinfo -sysprops process_id  
    这包括通过命令行-D标志设置的所有属性，应用动态添加的所有属性和JVM的默认属性
    
* 查看JVM版本
    
    jcmd process_id VM.version
    
* jconsole的”VM摘要“页可以显示程序所用的命令行，或者用jcmd显示
    
    jcmd process_id VM.command_line
    
* 获取对应用生效的JVM调优标志
    
    jcmd process_id VM.flags [-all]
    
* 获取进程中所有标志的值
    
    jinfo -flag PrintGCDetails process_id
    

小结：

1. jcmd可用来查找运行中的应用所在JVM的基本信息，包括所有调优标志的值。
    
2. 命令行上添加-XX:+Printflagsfinal可输出标志的默认值。这在查看特定平台自动优化所判定的默认值是很有用。
    
3. jinfo在检查(某些情况加可以更改)单个标志时很有用
    

#### 线程信息

jconsole和jvisualvm可以实时显示应用中运行的线程数量。

* 查看运行线程的栈信息，对于判断线程是否阻塞很有用。
    
    jstack process_id
    
* 通过jcmd获取栈信息
    
    jcmd process_id Thread.print
    

#### 类信息

jconsole和jstat可以提供应用已使用类的个数。jstat还能提供类编译相关的信息。

#### 实时GC分析

jconsole可以用实时图显示堆的使用情况。jcmd可以执行GC操作。jmap可以打印堆的概况，永久代信息或者创建堆转储。jstat可以为垃圾收集器正在执行的操作生成许多视图

#### 事后堆转储

jvisualvm的GUI界面可以捕获堆转储，可以用命令行jcmd或jmap生成。堆转储是堆使用情况的快照，可以用不同的工具进行分析，包括jvisualvm和jhat。传统上，第三方处理堆转储的工具都领先JDK，像Eclipse Memory Analyzer Tool。
