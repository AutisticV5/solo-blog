title: 基于LNMP+Wordpress搭建个人博客
date: '2019-11-08 23:46:26'
updated: '2019-11-09 07:02:13'
tags: [LNMP, WordPress, 博客]
permalink: /articles/2019/11/08/1573227986827.html
---
![](https://img.hacpai.com/bing/20180918.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 基于LNMP+Wordpress搭建个人博客

centos7版本

#### 操作步骤

### 安装 Nginx

 执行以下命令，在 `/etc/yum.repos.d/` 下创建 `nginx.repo` 文件。 

```shell
vi /etc/yum.repos.d/nginx.repo
```

 按 “**i**” 或 “**Insert**” 切换至编辑模式，写入以下内容。 

```shell
[nginx] 
name = nginx repo 
baseurl = https://nginx.org/packages/mainline/centos/7/$basearch/ 
gpgcheck = 0 
enabled = 1
```

按 “**Esc**”，输入 “**:wq**”，保存文件并返回。

执行以下命令，安装 nginx。

```shell
yum install nginx
```

 执行以下命令，打开 `nginx.conf` 文件。 

```shell
vim /etc/nginx/nginx.conf
```

 按 “**i**” 或 “**Insert**” 切换至编辑模式，对应使用的操作系统编辑 `nginx.conf` 文件。
用于取消对 IPv6 地址的监听，同时配置 Nginx，实现与 PHP 的联动。 

```txt
说明：
找到 nginx.conf 文件中的 #gzip on;，另起一行并输入以下内容。
```

```shell
server {
 listen       80;
 root   /usr/share/nginx/html;
 server_name  localhost;
 #charset koi8-r;
 #access_log  /var/log/nginx/log/host.access.log  main;
 #
 location / {
       index index.php index.html index.htm;
 }
 #error_page  404              /404.html;
 #redirect server error pages to the static page /50x.html
 #
 error_page   500 502 503 504  /50x.html;
 location = /50x.html {
   root   /usr/share/nginx/html;
 }
 #pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
 #
 location ~ .php$ {
   fastcgi_pass   127.0.0.1:9000;
   fastcgi_index  index.php;
   fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name;
   include        fastcgi_params;
 }
}
```

按 “**Esc**”，输入 “**:wq**”，保存文件并返回。

根据安装操作系统的不同，依次执行对应命令启动 Nginx 并设置为开机自启动。


```shell
systemctl start nginx
systemctl enable nginx
```

 在浏览器中，输入云服务器实例公网 IP，查看 Nginx 服务是否正常运行。
显示如下，则说明 Nginx 安装配置成功。 

![image-20191102185254556](C:\Users\wzxin\AppData\Roaming\Typora\typora-user-images\image-20191102185254556.png)

### 安装数据库

#### CentOS 7 安装 MariaDB

 执行以下命令，查看系统中是否存在 MariaDB 现有包。 

```shell
rpm -qa | grep -i mariadb
```

 执行以下命令，删除 MariaDB 现有包。 

```shell
yum -y remove 包名
```

 执行以下命令，在 `/etc/yum.repos.d/` 下创建 `MariaDB.repo` 文件。 

```shell
vi /etc/yum.repos.d/MariaDB.repo
```

 按 “**i**” 或 “**Insert**” 切换至编辑模式，写入以下内容。 

```shell
# MariaDB 10.4 CentOS7-amd64
[mariadb]  
name = MariaDB  
baseurl = http://mirrors.cloud.tencent.com/mariadb/yum/10.4/centos7-amd64/
gpgkey = http://mirrors.cloud.tencent.com/mariadb/yum/RPM-GPG-KEY-MariaDB
gpgcheck=1
```

 按 “**Esc**”，输入 “**:wq**”，保存文件并返回。 

 执行以下命令，安装 MariaDB。 

```
yum -y install MariaDB-client MariaDB-server
```

 依次执行以下命令，启动 MariaDB 服务，并设置为开机自启动。 

```shell
systemctl start mariadb
systemctl enable mariadb
```

 执行以下命令，验证 MariaDB 是否安装成功。 

```shell
mysql
```

### 安装配置 PHP

#### CentOS 7安装配置 PHP

 依次执行以下命令，更新 yum 中 PHP 的软件源。 

```shell
rpm -Uvh https://mirrors.cloud.tencent.com/epel/epel-release-latest-7.noarch.rpm
rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rpm
```

 执行以下命令，安装 PHP 7.2.22 所需要的包。 

```shell
yum -y install mod_php72w.x86_64 php72w-cli.x86_64 php72w-common.x86_64 php72w-mysqlnd php72w-fpm.x86_64
```

### 验证环境配置是否成功

 执行以下命令，创建测试文件。 

```shell
echo "<?php phpinfo(); ?>" >> /usr/share/nginx/html/index.php
```

 执行以下命令： 

```shell
systemctl restart nginx
service php-fpm start
```

 在浏览器中访问如下地址，查看环境配置是否成功。 

```
http://IP
```

 执行以下命令，进入 MariaDB。 

```java
mysql
```

 执行以下命令，创建 MariaDB 数据库。例如 “wordpress”。 

```java
CREATE DATABASE wordpress;
```

 执行以下命令，创建一个新用户。例如 “user”，登录密码为 `123456`。 

```java
CREATE USER 'user'@'localhost' IDENTIFIED BY '123456';
```

 执行以下命令，赋予用户对 “wordpress” 数据库的全部权限。 

```java
GRANT ALL PRIVILEGES ON wordpress.* TO 'user'@'localhost' IDENTIFIED BY '123456';
```

 执行以下命令，使所有配置生效。 

```shell
FLUSH PRIVILEGES;
```

 执行以下命令，退出 MariaDB。 

```
\q
```

### 配置 root 帐户

 执行以下命令，进入 MariaDB。 

```shell
mysql
```

 执行以下命令，设置 root 帐户密码。 

```txt
说明：
MariaDB 10.4 在 CentOS 系统上已增加了 root 帐户免密登录功能，请执行以下步骤设置您的 root 帐户密码并牢记。
```

```shell
ALTER USER root@localhost IDENTIFIED VIA mysql_native_password USING PASSWORD('输入您的密码');
```

 执行以下命令，退出 MariaDB。 

```shell
\q
```

### 安装和配置 WordPress

#### 下载 WordPress

```
说明：
WordPress 可从 WordPress 官方网站 下载 WordPress 最新中文版本并安装，本教程采用 WordPress 中文版本。
```

 执行以下命令，删除网站根目录下用于测试 PHP-Nginx 配置的`index.php`文件。 

```shell
rm -rf /usr/share/nginx/html/index.php
```

 依次执行以下命令，进入`/usr/share/nginx/html/`目录，并下载与解压 WordPress。 

```shell
cd /usr/share/nginx/html
wget https://cn.wordpress.org/wordpress-5.0.4-zh_CN.tar.gz
tar zxvf wordpress-5.0.4-zh_CN.tar.gz
```

#### 修改 WordPress 配置文件

 依次执行以下命令，进入 WordPress 安装目录，将`wp-config-sample.php`文件复制到`wp-config.php`文件中，并将原先的示例配置文件保留作为备份。 

```shell
cd /usr/share/nginx/html/wordpress
cp wp-config-sample.php wp-config.php
```

 执行以下命令，打开并编辑新创建的配置文件。 

```shell
vim wp-config.php
```

 按 “**i**” 切换至编辑模式，找到文件中 MySQL 的部分，并将相关配置信息修改为 [配置 WordPress 数据库](https://cloud.tencent.com/document/product/213/8044#database) 中的内容。 

```shell
// ** MySQL settings - You can get this info from your web host ** //
 /** The name of the database for WordPress */
 define('DB_NAME', 'wordpress');

 /** MySQL database username */
 define('DB_USER', 'user');

 /** MySQL database password */
 define('DB_PASSWORD', '123456');

 /** MySQL hostname */
 define('DB_HOST', 'localhost');
```

 修改完成后，按“**Esc**”，输入“**:wq**”，保存文件返回。 

### 验证 WordPress 安装

 在浏览器地址栏输入云服务器实例的公网 IP 加上 wordpress 文件夹，例如： 

```shell
http://192.xxx.xxx.xx /wordpress
```

 转至 WordPress 安装页，开始配置 WordPress。 

![image-20191102190459389](C:\Users\wzxin\AppData\Roaming\Typora\typora-user-images\image-20191102190459389.png)

注意：建议将wordpress的文件夹及其子文件夹的读写权限修改为777，同时修改wp-config.php文件

在该文件里面添加如下内容：

```shell
define("FS_METHOD", "direct");
define("FS_CHMOD_DIR", 0777);
define("FS_CHMOD_FILE", 0777);
```


